import 'package:flutter/material.dart';

@immutable
class AuthInfo {}
