import 'package:clarified_mobile/parents/models/parents.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

class NotificationSettingsScreen extends ConsumerWidget{
  NotificationSettingsScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    
    final profile = ref.watch(parentProfileProvider);
      return Scaffold(
       appBar: AppBar(
        title: const Text('Notifications setting'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios),
          onPressed: () {
            context.pop();
            // Add your onPressed code here!
          },
        ),
      
      centerTitle: true,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal:10.0,vertical: 10),
              child: Text('In this section, you will be able to manage notifications. We will continue to  send you notifications for security reasons.',textAlign: TextAlign.center,),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal:16.0,vertical: 10),
              child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.7,child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('In App Notifications',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 16),),
                  Text('You will receive a notification inside the application.',style: TextStyle(fontWeight: FontWeight.w400,fontSize: 14),),
                ],
              ),),
              Switch(value: profile.asData?.value.inAppNotification??true, onChanged: (value){
                   ref.watch(updateParentInAppNotificationProvider(value));
              },activeColor: Color(0xff34C759),)
            ],),
          ),

           Padding(
            padding: const EdgeInsets.symmetric(horizontal:16.0,vertical: 10),
              child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
              SizedBox(width: MediaQuery.of(context).size.width*0.7,child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Update Application',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 16),),
                  Text('You will receive a notification about update application.',style: TextStyle(fontWeight: FontWeight.w400,fontSize: 14),),
                ],
              ),),
              Switch(value: profile.asData?.value.appUpdateNotification??true, onChanged: (value){
                ref.watch(updateParentAppUpdateNotificationProvider(value));
              },activeColor: Color(0xff34C759),)
            ],),
          )
        ],
      ),
    );
 
  }
}
