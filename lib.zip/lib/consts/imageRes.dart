class ImageRes {

  static String profileImage = 'assets/image.png';
  static String manImage = 'assets/man.png';
  static String bookImage = 'assets/book.png';
  static String groupUserImage = 'assets/group.png';
  static String childersImage = 'assets/childers.png';
  static String frameImage = 'assets/frame.png';

}