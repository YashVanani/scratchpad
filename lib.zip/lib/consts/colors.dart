
import 'package:flutter/material.dart';

const Color liteGreenColor =  Color(0xFF0E9384);
const Color textMainColor =  Color(0xFF1D2939);
const Color whiteColor =  Color(0xFFFFFFFF);
const Color secondTextColor =  Color(0xFFF9FAFB);
const Color purpleColor =  Color(0xFFB190B6);
const Color greyTextColor =  Color(0xFF475467);
const Color greenTextColor =  Color(0xFF04686E);
const Color whiteTextColor =  Color(0xFFEAECF0);
const Color yellowColor =  Color(0xFFFAC515);
const Color skyeColor =  Color(0xFFCCFBEF);
const Color skyeWhiteColor =  Color(0xFFF6FEFC);
const Color boxColor =  Color(0xFF15B79E);
const Color boxOrangeColor =  Color(0xFFFEFAF5);
const Color orangeBorderColor =  Color(0xFFF9DBAF);
const Color orangeColor =  Color(0xFFEF6820);
const Color blueColor =  Color(0xFFE3E2FE);
const Color blueBorderColor =  Color(0xFFD3D1FF);
const Color darkBlueColor =  Color(0xFF00359E);
const Color darkGreenColor =  Color(0xFF027A48);
const Color tabBarColor =  Color(0xFF03494D);
const Color buttonColor =  Color(0xFF0B9099);